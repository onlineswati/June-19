'use strict';

var app = angular.module('rserveProject', ['tableSort', 'angularFileUpload']);

app.controller('MainCtrl', function($scope, $http, $interval, $q, $cacheFactory, FileUploader) {
	// Init
//	$http.get('/RserveProjectWeb/UploadServlet').then(function(response){
//		console.log('Init completed');
//	});
	
	// Upload script scope
	$scope.scriptStatus = 'choose files';
	
	var uploader = $scope.uploader = new FileUploader({
        url: '/RserveProjectWeb/ScriptUploadServlet'
    });

	uploader.onAfterAddingFile = function(fileItem) {
        console.info('onAfterAddingFile', fileItem.file.name);
        $scope.scriptStatus+=fileItem.file.name+"; ";
    };
    
    uploader.onCompleteAll = function() {
        console.info('onCompleteAll');
        $scope.scriptStatus="Uploaded";
    };
    
	console.log('uploader -> '+JSON.stringify(uploader));
	
	// Read scripts scope
	$http.get('/RserveProjectWeb/rest/main/getScripts').then(function(response){
		var data = $scope.scripts = response.data;
		console.log("scripts: "+data);
	});
	
	// Table scope
	var getAllUrl = '/RserveProjectWeb/rest/main/getAll';	
	$scope.records = [];
	var tmpData;
	var refreshTable = function(batch){
		//alert("dfhdgh");
		$http.get(getAllUrl).then(function(response) {
			tmpData = response.data;
			$scope.records = [];
			for (var i = 0; i < tmpData.length; i++) {
				if(tmpData[i][1]!='Geo tagging')
					$scope.records.push({id: tmpData[i][0], file: tmpData[i][1], startDate: tmpData[i][2], endDate: tmpData[i][3], status: tmpData[i][4], user: tmpData[i][5]});
			}
			//console.log(JSON.stringify($scope.records));
		});
	}

	refreshTable();
	$interval(function(){
		refreshTable();
	}, 5000);

	$scope.refreshTable = function(){
		refreshTable();
	}

	$scope.stop = function(){
		// Read scripts scope
		$http.get('/RserveProjectWeb/rest/main/stop?batchId='+$scope.filename).then(function(response){
			location.reload();
		});
	}
	
	$scope.deleteTable = function(){
		$http.delete('/RserveProjectWeb/rest/main/deleteAll').then(function(){
			refreshTable();
		});
		console.log('All records was deleted');
		refreshTable();
		//angular.element(document.querySelector("#tbody")).text('');
		
	}
	
	$scope.checkValidation = function($event){
		//alert(form.filename.value);
		if(form.filename.value==""){
			alert("Please enter batch id");
			$event.preventDefault();
		}else if(!($scope.form.$valid)){	
			alert("Please enter valid batch id");
			$event.preventDefault();
		}
		
	}

	$scope.displayMsg =function(){
		if($scope.selectedItem=="Dynamic_Account_Attr_Post_Acq.R")
			$scope.msg="Please select Account, Inquiry, Ioi and Summary csv input files";
		else if($scope.selectedItem=="Dynamic_Account_Attr_Pre_Acq.R")
			$scope.msg="Please select Account csv input file";
		else if($scope.selectedItem=="Dynamic_Inq_Attr_Pre_Acq.R")
			$scope.msg="Please select Account, Summary csv input files";
		else if($scope.selectedItem=="Dynamic_Inquiry_Attributes_Post_Acq.R")
			$scope.msg="Please select Account, Inquiry, Ioi and Summary csv input files";
		else if($scope.selectedItem=="Dynamic_Post_Acq_Inquiry_Incremental_Var.R")
			$scope.msg="Please select Account, Inquiry, Ioi and Summary csv input files";
	}
	// Sorting
	$scope.propertyName = 'id';
 	$scope.reverse = false;

	$scope.sortBy = function(propertyName) {
    $scope.reverse = ($scope.propertyName === propertyName) ? !$scope.reverse : false;
    $scope.propertyName = propertyName;
  };

});
