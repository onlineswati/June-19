'use strict';

var app = angular.module('ruTagging', ['angularFileUpload']);

app.controller('ruTaggingCtrl', function($scope, $http, $interval, $q, $cacheFactory, FileUploader) {

	
    $scope.checkValidation = function($event){
		//alert(form.filename.value);
		if(form.mfiId.value.length>10){
			alert("Mfi Id should be 10 digit");
			$event.preventDefault();
		}
	}

});
