package servlets;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.LineNumberReader;
import java.util.List;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

import utils.RunRUTaggingProcedure;
import utils.Storage;
import constants.Init;

public class RUTaggingServlet  extends HttpServlet {

	
	private final Logger LOG = Logger.getLogger(RUTaggingServlet.class);
	private static final long serialVersionUID = 1L;
	private static final int MAX_MEMORY_SIZE = Init.MAX_MEMORY_SIZE;
	private static final int MAX_REQUEST_SIZE = Init.MAX_REQUEST_SIZE;
	
	private Storage storage;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {

		Init.CONTEXT_PATH=getServletContext().getRealPath("database.properties");
		
		try { 
			getServletContext().getRequestDispatcher("/ruTagging.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		if(request.getSession().getAttribute("userName")==null){
			response.sendRedirect("./");
			return;
		}
		
		boolean isMultipart = ServletFileUpload.isMultipartContent(request);
		if (!isMultipart) {
			return;
		}
		
		storage = new Storage();
		
		Properties properties=new Properties();
		InputStream input=new FileInputStream(getServletContext().getRealPath("server.properties"));
		properties.load(input);
		
		DiskFileItemFactory factory = new DiskFileItemFactory();
		factory.setSizeThreshold(MAX_MEMORY_SIZE);
		factory.setRepository(new File(System.getProperty("java.io.tmpdir")));
		
		String uploadFolder = properties.getProperty("RuTagging.UploadFolder.Path");
		
		ServletFileUpload upload = new ServletFileUpload(factory);
		upload.setSizeMax(MAX_REQUEST_SIZE);
		List<FileItem> multiparts =null;

		String mfiID="";
		String fileName = null;
		try {
				
				multiparts = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);
							
				for (FileItem item : multiparts) {
					if (item.isFormField() && item.getFieldName().equals("mfiId")) {
						mfiID=item.getString();
						request.getSession().setAttribute("mfiID", mfiID);
					} 
				}
				
				//Make folder
				File uploadedFileDir = new File(uploadFolder);
			    if(!uploadedFileDir.exists())
			    	FileUtils.forceMkdir(uploadedFileDir);
			    
				for (FileItem item : multiparts) {
					synchronized (this) {
						if (!item.isFormField()) {
							fileName = new File(item.getName()).getName();
							String inputFilePath = uploadFolder + File.separator + fileName;
						    File uploadedFile = new File(inputFilePath);
							item.write(uploadedFile);
						}
					}
				}				
				
				System.out.println("File Name: "+fileName);
				
			    long count=lineCount(uploadFolder + File.separator + fileName);
			    System.out.println("Row count"+count);
			    request.getSession().setAttribute("fileName", fileName);
			    
				new RunRUTaggingProcedure(fileName,mfiID,uploadFolder,count).start();						
				response.sendRedirect("/RserveProjectWeb/ruTagging.jsp");
			    
			} catch (Exception ex) {
				LOG.error(ex);
				ex.printStackTrace();
				throw new ServletException(ex);
			}
	}
	
	
	public long lineCount(String path) {
		
		
		try {
			LineNumberReader line=new LineNumberReader(new FileReader(new File(path)));
			line.skip(Long.MAX_VALUE);
			return line.getLineNumber()+1;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
		
	}
	
	
	
	
	
}