package servlets;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import constants.Init;

public class DownloadReportServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		Init.SERVLET_CONTEXT_PATH = Init.SCRIPT_DATA_DIRECTORY;
		Init.CONTEXT_PATH=getServletContext().getRealPath("database.properties");
		try { 
			
				
				if(request.getSession().getAttribute("userName")==null){
					response.sendRedirect("./");
					return;
				}
				
				String batchId=request.getParameter("batchId");
				//String startDate=request.getParameter("startDate");
				
				Properties properties=new Properties();
				InputStream input=new FileInputStream(getServletContext().getRealPath("server.properties"));
				properties.load(input);
				
				Calendar cal = Calendar.getInstance();
				//System.out.println();
				
			 	ServletContext context = getServletContext();
			 	/*String filePath=properties.getProperty("RuTagging.UploadFolder.Path")+File.separator
			 			+"RU_TAGGING_INS0000001_"+batchId+"_"+new SimpleDateFormat("MMM").format(cal.getTime())+"_"+new SimpleDateFormat("YY").format(cal.getTime())+".txt";
			 	*/
			 	
			 	String filePath=properties.getProperty("RuTagging.UploadFolder.Path")+File.separator
			 			+"RU_TAGGING_"+request.getSession().getAttribute("mfiID").toString()+"_"+batchId+"_"+new SimpleDateFormat("MMM").format(cal.getTime()).toUpperCase()+"_"+new SimpleDateFormat("YY").format(cal.getTime())+".txt";
			 	
			 	System.out.println("Download  File Path  "+filePath);
			 	
			 	File saveFile=new File(filePath);
			 	FileInputStream saveFileStream=new FileInputStream(saveFile);
		        // gets MIME type of the file0
		        String mimeType = context.getMimeType(filePath);
		        if (mimeType == null) {        
		            // set to binary type if MIME mapping not found
		            mimeType = "application/octet-stream";
		        }
		        System.out.println("MIME type: " + mimeType);
		         
		        
		        // modifies response
		        response.setContentType(mimeType);
		        response.setContentLength((int) saveFile.length());
				
		        String headerKey = "Content-Disposition";
		        String headerValue = String.format("attachment; filename=\"%s\"", saveFile.getName()+".txt");
		        response.setHeader(headerKey, headerValue);

		        
		        // obtains response's output stream
		        OutputStream outStream = response.getOutputStream();
		         
		        byte[] buffer = new byte[4096];
		        int bytesRead = -1;
		         
		        while ((bytesRead = saveFileStream.read(buffer)) != -1) {
		            outStream.write(buffer, 0, bytesRead);
		        }
		         
		        saveFileStream.close();
		        outStream.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		System.out.println("In post");
	}
}
