package calls;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.xml.ws.RequestWrapper;

import org.apache.commons.io.FileUtils;

import utils.DateUtils;
import utils.Storage;
import constants.Init;


@Path("main")
@Produces(MediaType.APPLICATION_JSON)
public class RestCalls {
	
	private Storage storage;
	private Map<String, String> result;
	@Context ServletContext context;
	
	@GET
	@Path("getScripts")
	public String[] getScripts(){
		String uploadFolder = Init.SERVLET_CONTEXT_PATH;
				
		File uploadFolderPath = null;
		try{
			uploadFolderPath = new File(uploadFolder);
		}catch(NullPointerException e){
			String urlString = Init.LOCAL_URL+"/RserveProjectWeb/UploadServlet";
			URL url;
			try {
				url = new URL(urlString);
				URLConnection conn = url.openConnection();
				System.out.println(conn.getContent());
				uploadFolder = Init.SERVLET_CONTEXT_PATH;
				uploadFolderPath = new File(uploadFolder);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		if(!uploadFolderPath.exists()){
			uploadFolderPath.mkdir();
			System.out.println("Scripts dir createtd");
		}

		String[] files = uploadFolderPath.list();
		return files;
	}
	
	@DELETE
	@Path("deleteAll")
	public void test(@Context HttpServletRequest request){
		storage = new Storage();
		storage.deleteAll(request.getSession().getAttribute("userName").toString());
	}
	
	@GET
	@Path("stop")
	public void stop(@Context HttpServletRequest request){
		storage = new Storage();
		//Give you set of Threads
		Set<Thread> setOfThread = Thread.getAllStackTraces().keySet();

		//Iterate over set to find yours
		for(Thread thread : setOfThread){
		    if(thread.getId()==Long.parseLong(request.getSession().getAttribute("threadId").toString())){
		    	System.out.println("Thread interrupt");
		        thread.stop();
		        try {
		     // clean input data directory
				//FileUtils.cleanDirectory(new File(Init.DATA_DIRECTORY));
				Properties properties=new Properties();
				InputStream input=new FileInputStream(context.getRealPath("/server.properties"));
				properties.load(input);
					
				String filePath=properties.getProperty("Server.FilePath.Ubuntu");
				// clean temp folder
				//FileUtils.cleanDirectory(new File(filePath));
				// clean output folder
				
					//FileUtils.cleanDirectory(new File(Init.BASE_DIRECTORY+File.separator+"Output"));
					FileUtils.deleteDirectory(new File(Init.BASE_DIRECTORY+File.separator+request.getParameter("batchId")));
					
					Object[] dataForSaving = {request.getParameter("batchId") ,"", DateUtils.getTime(), DateUtils.getTime(),
							"Abort", "-" };
					
						storage.updateDbData(dataForSaving);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("Files deleted");
		    }
		}
	}
	
	@GET
	@Path("getAll")
	public List<Object[]> getAll(@Context HttpServletRequest request){
		storage = new Storage();
		Init.SERVLET_CONTEXT_PATH =Init.SCRIPT_DATA_DIRECTORY;
		Init.CONTEXT_PATH=context.getRealPath("database.properties");
		return storage.getDbData(request.getSession().getAttribute("userName").toString());
	}
	
	private Map<String, String> toObject(String key, String value){
		result = new HashMap<>();
		result.put(key, value);
		return result;
	}
	
	@GET
	@Path("getFileInstId")
	public long getFileInstId(@Context HttpServletRequest request){
		storage = new Storage();
		Init.CONTEXT_PATH=context.getRealPath("database.properties");
		return storage.getMaxFileInstId(Init.CONTEXT_PATH,request.getSession().getAttribute("mfiID").toString());
	}
	
	@GET
	@Path("updateFileInstId")
	public String updateFileInstId(@Context HttpServletRequest request){
		storage = new Storage();
		Init.CONTEXT_PATH=context.getRealPath("database.properties");
		return storage.updateFileInstId(Init.CONTEXT_PATH,request.getParameter("mfiId"));
	}
	
}
