package utils;

import java.io.File;
import java.util.List;

import org.rosuda.REngine.Rserve.RConnection;

import constants.Init;

public class Rserve {
	
	private RConnection rConnection;
	private long end;
	private Storage storage;
	
	public void rEvent(String id, String file, long startTime) throws Exception {
		end = DateUtils.getTime();
		storage = new Storage();
		try {
			rConnection = new RConnection();
			System.out.println("res file: "+Init.RSOURCEFILE);
			
			rConnection.eval(Init.RSOURCEFILE);
			rConnection.close();
			end = DateUtils.getTime();
			//int counter = 0;
			//for(File file: files) {
				System.out.println("saving status for file : " + file);
				Object[] dataForSaving = {id, file, startTime, end, "Success"};
				storage.updateDbData(dataForSaving);
			///}
			
			System.out.println("successfully completed");
			
		} catch (Exception e) {
			
			System.out.println("ERROR: " + e.getMessage());
			e.printStackTrace();
			throw e;
		}
	
	}
}