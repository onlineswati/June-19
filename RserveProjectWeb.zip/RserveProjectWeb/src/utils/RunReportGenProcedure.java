package utils;

import java.io.IOException;

import org.apache.log4j.Logger;

public class RunReportGenProcedure extends Thread{
	
	
	private final Logger LOG = Logger.getLogger(RunReportGenProcedure.class);
	
	private String batchId="";
	private String path="";
	private String filename="";
	
	private Storage storage = new Storage();
	
	public RunReportGenProcedure(String batchId,String path,String filename) 
			throws IOException {
		
		this.batchId=batchId;
		this.path=path;
		this.filename=filename;
		
	}


	@Override
	public void run(){  
		System.out.println("process is running...");  
		
		try {
			
			storage.runPrRUTaggingProcedure(batchId,path,filename);
			
			
		} catch (Exception ex) {
			LOG.error(ex);
			ex.printStackTrace();
		}
		System.out.println("process is End...");  
	} 	
}
