package utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.log4j.Logger;

public class RunRUTaggingProcedure extends Thread{
	
	
	private final Logger LOG = Logger.getLogger(RunRUTaggingProcedure.class);
	
	String fileName="";
	private String mfiId;
	private String path;
	private long count;
	
	private Storage storage = new Storage();
	
	public RunRUTaggingProcedure(String fileName,String mfiId,String path,long count){
		this.fileName=fileName;
		this.mfiId=mfiId;
		this.path=path;
		this.count=count;
	}


	@Override
	public void run(){  
		System.out.println("process is running...");  
		try {
			
			//storage.runPRBatchProcessProcedure(fileName,mfiId,path);

			String[] parameter={path+File.separator +"Shell_Ru_Tagg_Final_.sh",fileName,mfiId,Long.toString(count)};
			ProcessBuilder pb2=new ProcessBuilder(parameter);
			
			Process script_exec = pb2.start();
			script_exec.waitFor();
			StringBuffer out=new StringBuffer();
			BufferedReader bufReader=new BufferedReader(new InputStreamReader(script_exec.getInputStream()));
			String line="";
			while((line= bufReader.readLine())!=null){
				System.out.println(line);
				out.append(line+"\n");
			}
			
		} catch (Exception ex) {
			LOG.error(ex);
			ex.printStackTrace();
		}
		
		System.out.println("process is completed...");  
	} 	
}
