package utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Timestamp;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

import constants.Init;

public class ProcessRequest extends Thread{
	
	
	private static final String DATA_DIRECTORY = Init.DATA_DIRECTORY;
	private static final int MAX_MEMORY_SIZE = Init.MAX_MEMORY_SIZE;
	private static final int MAX_REQUEST_SIZE = Init.MAX_REQUEST_SIZE;
	private static final String STATUS_PAGE = Init.STATUS_PAGE;
	private final Logger LOG = Logger.getLogger(ProcessRequest.class);
	
	// date & time vars
	private long start;
	
	File saveFile = null;
	String filePath = null,fileName = null;
	String outputDir = Init.BASE_DIRECTORY;
	
	private Storage storage = new Storage();
	private Rserve rserve = new Rserve();
	
	String outpFileName;
	
	boolean flag=false;
	String scriptName="";
	String batchId="";
	String fileBasePath;
	String uploadFolder,userName;
	Properties properties=new Properties();
	
	
	public ProcessRequest(String fileName,String scriptName,String uploadFolder,
			String outpFileName, long start,String batchId,String filePath,
			 String outputDir, String fileBasePath,String userName,String scriptPath) throws IOException {
		
		this.start = start;
		this.filePath = filePath;
		this.fileName = fileName;
		this.outputDir = outputDir;
		this.outpFileName = outpFileName;
		this.scriptName = scriptName;
		this.batchId = batchId;
		this.fileBasePath = fileBasePath;
		this.uploadFolder = uploadFolder;
		this.userName=userName;
		InputStream input=new FileInputStream(scriptPath);
		properties.load(input);
	}


	@Override
	public void run(){  
		System.out.println("process is running...");  
		try {
			if(scriptName.equals("Dynamic_Inquiry_Attributes_Post_Acq.R")){
		    	FileUtils.writeStringToFile(new File(Init.SCRIPT_DATA_DIRECTORY1+File.separator+"awk_name.txt"), outpFileName);
				String path =uploadFolder;
				String[] parameter={properties.getProperty("script.Dynamic_awk_variable_generation"),path};
				ProcessBuilder pb2=new ProcessBuilder(parameter);
				System.out.println("Dynamic_awk_variable_generation.sh is running");
				try {
					Process script_exec = pb2.start();
					script_exec.waitFor();
					StringBuffer out=new StringBuffer();
					BufferedReader bufReader=new BufferedReader(new InputStreamReader(script_exec.getInputStream()));
					String line="";
					while((line= bufReader.readLine())!=null){
						System.out.println(line);
						out.append(line+"\n");
						
					}
					System.out.println("Awk variable generated....");
					System.out.println("Dynamic_awk_variable_generation.sh is done");
				}catch(Exception e) {
					System.out.println("Exception while processing background job "+e.getMessage());
				}
			
			}
			
			if(scriptName.equals("Dynamic1_Account_Attr_Post_Acq.R")){
				String path =uploadFolder;
				String[] parameter={"/home/ubuntu/data/Project/scripts1/newawk.sh",path};
				ProcessBuilder pb2=new ProcessBuilder(parameter);
				
				try {
					Process script_exec = pb2.start();
					script_exec.waitFor();
					StringBuffer out=new StringBuffer();
					BufferedReader bufReader=new BufferedReader(new InputStreamReader(script_exec.getInputStream()));
					String line="";
					while((line= bufReader.readLine())!=null){
						System.out.println(line);
						out.append(line+"\n");
						
					}
					System.out.println("Awk variable generated....");
				}catch(Exception e) {
					System.out.println("Exception while processing background job "+e.getMessage());
				}
			
			}
			
			
			FileUtils.writeStringToFile(new File(Init.SCRIPT_DATA_DIRECTORY+File.separator+"batch_name.txt"), outpFileName);
			
			//fileName=multiparts.get(0).getString().replace(".R", "");
			System.out.println(fileName+" started");
			rserve.rEvent(outpFileName, scriptName ,start);
			System.out.println(fileName+" End");
		
		} catch (FileUploadException ex) {
			LOG.error(ex);
			//throw new ServletException(ex);
		} catch (Exception ex) {
			LOG.error(ex);
			flag=true;
			System.out.println("Error flag true");
			//throw new ServletException(ex);
		}finally{
			
			if(flag){
				Object[] dataForSaving = {batchId ,scriptName, start, start,
					"Error", "-" };
			
				storage.updateDbData(dataForSaving);
			}
			 
			  if(flag){
				// clean input data directory
					try {
						FileUtils.cleanDirectory(new File(uploadFolder));
						// clean temp folder
						FileUtils.cleanDirectory(new File(filePath));
						// clean output folder
						FileUtils.cleanDirectory(new File(outputDir));
						FileUtils.deleteDirectory(new File(fileBasePath));
						
						System.out.println("Files deleted");
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}  
			  }
		}
		
		try{
		
			if(scriptName.equals("Dynamic_Inquiry_Attributes_Post_Acq.R")) {
				FileUtils.writeStringToFile(new File(Init.SCRIPT_DATA_DIRECTORY1+File.separator+"merge_name.txt"), outpFileName);
				System.out.println("System is about merge files");
				try {
					System.out.println("Dynamic_Post_Acq_Inquiry_Attributes_Step2.r is running");
					Process p = Runtime.getRuntime().exec("Rscript "+properties.getProperty("script.Dynamic_Post_Acq_Inquiry_Attributes_Step2"));
					p.waitFor();
					System.out.println("Dynamic_Post_Acq_Inquiry_Attributes_Step2.R done");
				}catch(Exception e) {
					System.out.println("Exception while at merge "+e.getMessage());
				}
				System.out.println("merge is done ");
			}
			
			if(scriptName.equals("Dynamic1_Account_Attr_Post_Acq.R")){
				System.out.println("System is about merge files");
				try {
					Process p = Runtime.getRuntime().exec("Rscript /home/ubuntu/data/Project/scripts1/newpost.r");
					p.waitFor();
					
				}catch(Exception e) {
					System.out.println("Exception while at merge "+e.getMessage());
				}
				System.out.println("merge is done ");
			}
			
			
			String outputFile = outputDir + File.separator+fileName+".csv";
			saveFile=new File(outputFile);

			Date date=new Date(start);
			Format format=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

			
			if(saveFile.exists()){
				FileInputStream saveFileStream=new FileInputStream(saveFile);
				saveFile.renameTo(new File(Init.BASE_DIRECTORY+File.separator+"Outputs"+File.separator+batchId+"_"+scriptName+"_"+userName+"_"+format.format(date)+".csv"));
	    
	        //saveFile.delete();
			}else{
				flag=true;
			}
			
			
			// clean input data directory
			FileUtils.cleanDirectory(new File(uploadFolder));
			// clean temp folder
			FileUtils.cleanDirectory(new File(filePath));
			// clean output folder
			FileUtils.cleanDirectory(new File(outputDir));
			FileUtils.deleteDirectory(new File(fileBasePath));
			System.out.println("Files deleted");
			
		}catch(Exception e){
			e.printStackTrace();
		}
	} 
	
	
	/*public   void startRserver() throws IOException, InterruptedException {
		if (!rserveStarted) {
			System.out.println("Starting Rserve");
			rserveStartTime = new Date().getTime();
			rserveStarted = true;
			Properties properties=new Properties();
			InputStream input=new FileInputStream(getServletContext().getRealPath("/r.properties"));
			properties.load(input);
		
			// Ubuntu
			// Runtime.getRuntime().exec(properties.getProperty("Path.Ubuntu.RPATH"));	
		
			// Redhat
			   Runtime.getRuntime().exec(properties.getProperty("Path.Redhat.RPATH"));	
			Thread.sleep(5000);
			}
	}*/

	/*public static void stopRserver() throws IOException, InterruptedException {
		if (!rserveUploading) {
			rserveStarted = false;
			System.out.println("Stopping Rserve");
	
	    	Thread.sleep(5000);
		}
	}*/
	
	
}
